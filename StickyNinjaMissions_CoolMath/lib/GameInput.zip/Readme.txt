Read the following before using the files within this archive.

This archive contains files for the GameInput SWC posted on the Adobe AIR Developer Center:
http://www.adobe.com/devnet/air.html.

Use these files with the article to get started with the GameInput SWC for Ouya TV. 
The archive contains:
1) A Flash Builder project in the GameInputOuyaSample folder. 
2) The SWC representing the GameInputControlName class in the swc folder. 
3) ActionScript documentation in the Docs folder.

To use the sample:
1) Import the GameInputOuyaSample project into Flash Builder.
2) Build the project by selecting 'Export Release Build' from the Project menu.
3) Provide the certificate and password information.
4) Install GameInputOuyaSample.apk on a OUYA device.
5) Launch GameInputOuyaSample.apk from the menu on a OUYA device.
